let questions = [
    {
        numb: 1,
        question: "What is the speed of light in a vacuum?",
        answer: "A. 300,000 km/s",
        options: [
            "A. 300,000 km/s ",
            "B. 150,000 km/s ",
            "C. 3,000 km/s ",
            "D. 30,000 km/s "
        ]
    },
    {
        numb: 2,
        question: "Which law states that for every action, there is an equal and opposite reaction?",
        answer: "C. Newton's Third Law",
        options: [
            "A. Newton's First Law",
            "B. Newton's Second Law",
            "C. Newton's Third Law",
            "D. Law of Gravitation"
        ]
    },
    {
        numb: 3,
        question: "What is the unit of electrical resistance?",
        answer: "A. Ohm",
        options: [
            "A. Ohm",
            "B. Watt",
            "C. Ampere",
            "D. Volt"
        ]
    },
    {
        numb: 4,
        question: "Which fundamental force is responsible for holding the nucleus together?",
        answer:   "D. Strong Nuclear Force",
        options: [
            "A. Gravit",
            "B. Electromagnetic Force",
            "C. Weak Nuclear Force",
            "D. Strong Nuclear Force"
        ]
    },
    {
        numb: 5,
        question: "What is the acceleration due to gravity on Earth?",
        answer: "C. 9.8 m/s²",
        options: [
            "A. 8.9 m/s²",
            "B. 10.5 m/s²",
            "C. 9.8 m/s²",
            "D. 12.1 m/s²"
        ]
    }
];