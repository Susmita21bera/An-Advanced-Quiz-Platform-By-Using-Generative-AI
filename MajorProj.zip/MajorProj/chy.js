let questions = [
    {
        numb: 1,
        question: "What is the chemical symbol for gold?",
        answer: "A. Au",
        options: [
            "A. Au",
            "B. Ag",
            "C. Pb",
            "D. Fe"
        ]
    },
    {
        numb: 2,
        question: "What is the pH of pure water?",
        answer: "B. 7",
        options: [
            "A. 5",
            "B. 7",
            "C. 9",
            "D. 11"
        ]
    },
    {
        numb: 3,
        question: "Which gas is most abundant in Earth's atmosphere?",
        answer: "C. Nitroge",
        options: [
            "A. Oxygen",
            "B. Carbon Dioxide",
            "C. Nitroge",
            "D. Hydrogen"
        ]
    },
    {
        numb: 4,
        question: "What is the chemical formula for table salt",
        answer:   "A. NaCl",
        options: [
            "A. NaCl",
            "B. KCl",
            "C. CaCl2",
            "D. Na2SO4s"
        ]
    },
    {
        numb: 5,
        question: "Which element has the highest atomic number?",
        answer: "B. Oganesson",
        options: [
            "A. Uranium",
            "B. Oganesson",
            "C. Plutonium",
            "D. Radon"
        ]
    }
];