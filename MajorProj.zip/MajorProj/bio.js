let questions = [
    {
        numb: 1,
        question: "What is the basic unit of life?",
        answer: "B. Cell",
        options: [
            "A. Atom",
            "B. Cell",
            "C. Tissu",
            "D. Organ"
        ]
    },
    {
        numb: 2,
        question: "Which organelle is responsible for energy production?",
        answer: "C. Mitochondrion",
        options: [
            "A. Nucleus",
            "B. Ribosome",
            "C. Mitochondrion",
            "D. Golgi Apparatus"
        ]
    },
    {
        numb: 3,
        question: "Which molecule carries genetic instructions?",
        answer: "A. DNA",
        options: [
            "A. DNA",
            "B. RNA",
            "C. Protein",
            "D. Lipid"
        ]
    },
    {
        numb: 4,
        question: "What is the process by which plants make their own food?",
        answer:   "D. Photosynthesis",
        options: [
            "A. Respiration",
            "B. Fermentation",
            "C. Digestion",
            "D. Photosynthesis"
        ]
    },
    {
        numb: 5,
        question: "Which of the following is NOT a macromolecule found in living organisms?",
        answer: "D. Helium",
        options: [
            "A. Carbohydrates",
            "B. Proteins",
            "C. Nucleic Acids",
            "D. Helium"
        ]
    }
];