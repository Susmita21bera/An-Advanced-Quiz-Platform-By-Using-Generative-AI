from flask import Flask, request, jsonify
import fitz  # PyMuPDF for PDF processing
import requests
from bs4 import BeautifulSoup
import google.generativeai as genai  # Google Gemini API
import os
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)  # Allow all origins

# Load API key from environment variable
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("⚠️ Google Gemini API key is missing! Set GEMINI_API_KEY in your environment.")

# Configure Google Gemini API
genai.configure(api_key=GEMINI_API_KEY)

# ✅ Use the correct Gemini model
GEMINI_MODEL = "gemini-1.5-pro-latest"  # Change to "gemini-1.5-flash-latest" if needed

# Ensure the 'uploads' folder exists
if not os.path.exists("uploads"):
    os.makedirs("uploads")

def generate_questions(text, level, question_type):
    """ Generate quiz questions using Google Gemini API """
    text_chunk = text[:500]  # Reduce token usage
    prompt = f"""
    You are an AI quiz generator. Create a {level}-level {question_type} question based on the following content:
    {text_chunk}
    """

    try:
        model = genai.GenerativeModel(GEMINI_MODEL)  # Use the correct model
        response = model.generate_content(prompt)

        if hasattr(response, "text") and response.text.strip():
            return response.text.strip()
        else:
            return "⚠️ No response from Gemini API"
    except Exception as e:
        print(f"❌ Gemini API Error: {str(e)}")
        return f"Error generating question: {str(e)}"

def extract_text_from_pdf(file_path):
    """ Extracts text from a PDF file """
    text = ""
    try:
        doc = fitz.open(file_path)
        for page in doc:
            text += page.get_text("text") + "\n"
        return text if text.strip() else "⚠️ No readable text found in PDF"
    except Exception as e:
        return f"Error reading PDF: {str(e)}"

def extract_text_from_url(url):
    """ Extracts article content from a given URL """
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        return f"Error fetching URL: {str(e)}"

    soup = BeautifulSoup(response.text, "html.parser")
    paragraphs = soup.find_all("p")
    return " ".join([p.get_text() for p in paragraphs]) if paragraphs else "⚠️ No content found"

@app.route("/generate-quiz", methods=["POST"])
def generate_quiz():
    subject = request.form.get("subject", "").strip()
    url = request.form.get("url", "").strip()
    level = request.form.get("level", "").strip()
    question_type = request.form.get("questionType", "").strip()
    file = request.files.get("file")

    print("\n✅ Received Data from Frontend:")
    print("Subject:", subject)
    print("URL:", url)
    print("Level:", level)
    print("Question Type:", question_type)
    print("File:", file.filename if file else "No file uploaded")

    if not subject and not url and not file:
        print("⚠️ Error: No valid input provided")
        return jsonify({"error": "No valid input provided or error occurred"}), 400

    extracted_text = ""

    if file:
        file_path = os.path.join("uploads", file.filename)
        file.save(file_path)
        extracted_text = extract_text_from_pdf(file_path)
    elif url:
        extracted_text = extract_text_from_url(url)
    elif subject:
        extracted_text = f"A quiz about {subject}"

    if "Error" in extracted_text:
        return jsonify({"error": extracted_text}), 400

    # ✅ Improve error handling for API failures
    quiz_questions = []
    for _ in range(5):
        question = generate_questions(extracted_text, level, question_type)
        if "Error" in question:
            print(f"⚠️ Skipping failed question: {question}")
            continue
        quiz_questions.append(question)

    if not quiz_questions:
        return jsonify({"error": "No valid questions generated. Check API settings."}), 500

    print("✅ Generated Questions:", quiz_questions)

    # ✅ Redirect to quiz.html after success
    return jsonify({
        "questions": quiz_questions,
        "level": level,
        "question_type": question_type,
        "redirect_url": "/quiz.html"  # Redirect path
    })

if __name__ == "__main__":
    app.run(debug=True)
