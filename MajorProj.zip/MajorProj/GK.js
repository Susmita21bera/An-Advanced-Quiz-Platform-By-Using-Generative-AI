let questions = [
    {
        numb: 1,
        question: "In what year did the Great October Socialist Revolution take place?",
        answer: "A. 1917",
        options: [
            "A. 1917",
            "B. 1923",
            "C. 1914",
            "D. 1920"
        ]
    },
    {
        numb: 2,
        question: "What is the largest lake in the world?",
        answer: "B. Baikal",
        options: [
            "A. Caspian Sea",
            "B. Baikal",
            "C. Lake Superior",
            "D. Ontario"
        ]
    },
    {
        numb: 3,
        question: "Which planet in the solar system is known as the “Red Planet”?",
        answer: "C. Mars",
        options: [
            "A. Venus",
            "B. Earth",
            "C. Mars",
            "D. Jupiter"
        ]
    },
    {
        numb: 4,
        question: "Who wrote the novel “War and Peace”?",
        answer: "C. Leo Tolstoy",
        options: [
            "A. Anton Chekhov",
            "B. Fyodor Dostoevsky",
            "C. Leo Tolstoy",
            "D. Ivan Turgenev"
        ]
    },
    {
        numb: 5,
        question: "What is the capital of Japan?",
        answer: "B. Tokyo",
        options: [
            "A. Seoul",
            "B. Tokyo",
            "C. Beijing",
            "D. Bangkok"
        ]
    }
];